(function() {
  var $, CompositeDisposable, MouseEventWhichDict;

  $ = null;

  CompositeDisposable = require('atom').CompositeDisposable;

  MouseEventWhichDict = {
    "left click": 1,
    "middle click": 2,
    "right click": 3
  };

  module.exports = {
    disposable: null,
    config: {
      disableComplete: {
        title: 'Disable auto complete',
        type: 'boolean',
        "default": false
      },
      autoBuildTagsWhenActive: {
        title: 'Automatically rebuild tags',
        description: 'Rebuild tags file each time a project path changes',
        type: 'boolean',
        "default": false
      },
      buildTimeout: {
        title: 'Build timeout',
        description: 'Time (in milliseconds) to wait for a tags rebuild to finish',
        type: 'integer',
        "default": 10000
      },
      cmd: {
        type: 'string',
        "default": ""
      },
      cmdArgs: {
        description: 'Add specified ctag command args like: --exclude=lib --exclude=*.js',
        type: 'string',
        "default": ""
      },
      extraTagFiles: {
        description: 'Add specified tagFiles. (Make sure you tag file generate with --fields=+KSn)',
        type: 'string',
        "default": ""
      },
      GotoSymbolKey: {
        description: 'combine bindings: alt, ctrl, meta, shift',
        type: 'array',
        "default": ["alt"]
      },
      GotoSymbolClick: {
        type: 'string',
        "default": "left click",
        "enum": ["left click", "middle click", "right click"]
      }
    },
    provider: null,
    activate: function() {
      var initExtraTagsTime;
      this.stack = [];
      this.ctagsCache = require("./ctags-cache");
      this.ctagsCache.activate();
      this.ctagsCache.initTags(atom.project.getPaths(), atom.config.get('atom-ctags.autoBuildTagsWhenActive'));
      this.disposable = atom.project.onDidChangePaths((function(_this) {
        return function(paths) {
          return _this.ctagsCache.initTags(paths, atom.config.get('atom-ctags.autoBuildTagsWhenActive'));
        };
      })(this));
      atom.commands.add('atom-workspace', 'atom-ctags:rebuild', (function(_this) {
        return function(e, cmdArgs) {
          var t;
          console.error("rebuild: ", e);
          if (Array.isArray(cmdArgs)) {
            _this.ctagsCache.cmdArgs = cmdArgs;
          }
          _this.createFileView().rebuild(true);
          if (t) {
            clearTimeout(t);
            return t = null;
          }
        };
      })(this));
      atom.commands.add('atom-workspace', 'atom-ctags:toggle-project-symbols', (function(_this) {
        return function() {
          return _this.createFileView().toggleAll();
        };
      })(this));
      atom.commands.add('atom-text-editor', {
        'atom-ctags:toggle-file-symbols': (function(_this) {
          return function() {
            return _this.createFileView().toggle();
          };
        })(this),
        'atom-ctags:go-to-declaration': (function(_this) {
          return function() {
            return _this.createFileView().goto();
          };
        })(this),
        'atom-ctags:return-from-declaration': (function(_this) {
          return function() {
            return _this.createGoBackView().toggle();
          };
        })(this)
      });
      atom.workspace.observeTextEditors((function(_this) {
        return function(editor) {
          var editorView;
          editorView = atom.views.getView(editor);
          if (!$) {
            $ = require('atom-space-pen-views').$;
          }
          return $(editorView).on('mousedown', function(event) {
            var i, keyName, len, ref, which;
            which = atom.config.get('atom-ctags.GotoSymbolClick');
            if (MouseEventWhichDict[which] !== event.which) {
              return;
            }
            ref = atom.config.get('atom-ctags.GotoSymbolKey');
            for (i = 0, len = ref.length; i < len; i++) {
              keyName = ref[i];
              if (!event[keyName + "Key"]) {
                return;
              }
            }
            return _this.createFileView().goto();
          });
        };
      })(this));
      if (!atom.packages.isPackageDisabled("symbols-view")) {
        atom.packages.disablePackage("symbols-view");
        alert("Warning from atom-ctags: atom-ctags replaces and enhances the symbols-view package. Therefore, symbols-view has been disabled.");
      }
      atom.config.observe('atom-ctags.disableComplete', (function(_this) {
        return function() {
          if (!_this.provider) {
            return;
          }
          return _this.provider.disabled = atom.config.get('atom-ctags.disableComplete');
        };
      })(this));
      initExtraTagsTime = null;
      return atom.config.observe('atom-ctags.extraTagFiles', (function(_this) {
        return function() {
          if (initExtraTagsTime) {
            clearTimeout(initExtraTagsTime);
          }
          return initExtraTagsTime = setTimeout((function() {
            _this.ctagsCache.initExtraTags(atom.config.get('atom-ctags.extraTagFiles').split(" "));
            return initExtraTagsTime = null;
          }), 1000);
        };
      })(this));
    },
    deactivate: function() {
      if (this.disposable != null) {
        this.disposable.dispose();
        this.disposable = null;
      }
      if (this.fileView != null) {
        this.fileView.destroy();
        this.fileView = null;
      }
      if (this.projectView != null) {
        this.projectView.destroy();
        this.projectView = null;
      }
      if (this.goToView != null) {
        this.goToView.destroy();
        this.goToView = null;
      }
      if (this.goBackView != null) {
        this.goBackView.destroy();
        this.goBackView = null;
      }
      return this.ctagsCache.deactivate();
    },
    createFileView: function() {
      var FileView;
      if (this.fileView == null) {
        FileView = require('./file-view');
        this.fileView = new FileView(this.stack);
        this.fileView.ctagsCache = this.ctagsCache;
      }
      return this.fileView;
    },
    createGoBackView: function() {
      var GoBackView;
      if (this.goBackView == null) {
        GoBackView = require('./go-back-view');
        this.goBackView = new GoBackView(this.stack);
      }
      return this.goBackView;
    },
    provide: function() {
      var CtagsProvider;
      if (this.provider == null) {
        CtagsProvider = require('./ctags-provider');
        this.provider = new CtagsProvider();
        this.provider.ctagsCache = this.ctagsCache;
        this.provider.disabled = atom.config.get('atom-ctags.disableComplete');
      }
      return this.provider;
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZmlsZTovLy9DOi9Vc2Vycy9mbGlzei8uYXRvbS9wYWNrYWdlcy9hdG9tLWN0YWdzL2xpYi9tYWluLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUE7O0VBQUEsQ0FBQSxHQUFJOztFQUNILHNCQUF1QixPQUFBLENBQVEsTUFBUjs7RUFFeEIsbUJBQUEsR0FBc0I7SUFBQyxZQUFBLEVBQWMsQ0FBZjtJQUFrQixjQUFBLEVBQWdCLENBQWxDO0lBQXFDLGFBQUEsRUFBZSxDQUFwRDs7O0VBQ3RCLE1BQU0sQ0FBQyxPQUFQLEdBQ0U7SUFBQSxVQUFBLEVBQVksSUFBWjtJQUVBLE1BQUEsRUFDRTtNQUFBLGVBQUEsRUFDRTtRQUFBLEtBQUEsRUFBTyx1QkFBUDtRQUNBLElBQUEsRUFBTSxTQUROO1FBRUEsQ0FBQSxPQUFBLENBQUEsRUFBUyxLQUZUO09BREY7TUFJQSx1QkFBQSxFQUNFO1FBQUEsS0FBQSxFQUFPLDRCQUFQO1FBQ0EsV0FBQSxFQUFhLG9EQURiO1FBRUEsSUFBQSxFQUFNLFNBRk47UUFHQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLEtBSFQ7T0FMRjtNQVNBLFlBQUEsRUFDRTtRQUFBLEtBQUEsRUFBTyxlQUFQO1FBQ0EsV0FBQSxFQUFhLDZEQURiO1FBRUEsSUFBQSxFQUFNLFNBRk47UUFHQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLEtBSFQ7T0FWRjtNQWNBLEdBQUEsRUFDRTtRQUFBLElBQUEsRUFBTSxRQUFOO1FBQ0EsQ0FBQSxPQUFBLENBQUEsRUFBUyxFQURUO09BZkY7TUFpQkEsT0FBQSxFQUNFO1FBQUEsV0FBQSxFQUFhLG9FQUFiO1FBQ0EsSUFBQSxFQUFNLFFBRE47UUFFQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLEVBRlQ7T0FsQkY7TUFxQkEsYUFBQSxFQUNFO1FBQUEsV0FBQSxFQUFhLDhFQUFiO1FBQ0EsSUFBQSxFQUFNLFFBRE47UUFFQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLEVBRlQ7T0F0QkY7TUF5QkEsYUFBQSxFQUNFO1FBQUEsV0FBQSxFQUFhLDBDQUFiO1FBQ0EsSUFBQSxFQUFNLE9BRE47UUFFQSxDQUFBLE9BQUEsQ0FBQSxFQUFTLENBQUMsS0FBRCxDQUZUO09BMUJGO01BNkJBLGVBQUEsRUFDRTtRQUFBLElBQUEsRUFBTSxRQUFOO1FBQ0EsQ0FBQSxPQUFBLENBQUEsRUFBUyxZQURUO1FBRUEsQ0FBQSxJQUFBLENBQUEsRUFBTSxDQUFDLFlBQUQsRUFBZSxjQUFmLEVBQStCLGFBQS9CLENBRk47T0E5QkY7S0FIRjtJQXFDQSxRQUFBLEVBQVUsSUFyQ1Y7SUF1Q0EsUUFBQSxFQUFVLFNBQUE7QUFDUixVQUFBO01BQUEsSUFBQyxDQUFBLEtBQUQsR0FBUztNQUVULElBQUMsQ0FBQSxVQUFELEdBQWMsT0FBQSxDQUFRLGVBQVI7TUFFZCxJQUFDLENBQUEsVUFBVSxDQUFDLFFBQVosQ0FBQTtNQUVBLElBQUMsQ0FBQSxVQUFVLENBQUMsUUFBWixDQUFxQixJQUFJLENBQUMsT0FBTyxDQUFDLFFBQWIsQ0FBQSxDQUFyQixFQUE4QyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0Isb0NBQWhCLENBQTlDO01BQ0EsSUFBQyxDQUFBLFVBQUQsR0FBYyxJQUFJLENBQUMsT0FBTyxDQUFDLGdCQUFiLENBQThCLENBQUEsU0FBQSxLQUFBO2VBQUEsU0FBQyxLQUFEO2lCQUMxQyxLQUFDLENBQUEsVUFBVSxDQUFDLFFBQVosQ0FBcUIsS0FBckIsRUFBNEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLG9DQUFoQixDQUE1QjtRQUQwQztNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBOUI7TUFHZCxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQWQsQ0FBa0IsZ0JBQWxCLEVBQW9DLG9CQUFwQyxFQUEwRCxDQUFBLFNBQUEsS0FBQTtlQUFBLFNBQUMsQ0FBRCxFQUFJLE9BQUo7QUFDeEQsY0FBQTtVQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsV0FBZCxFQUEyQixDQUEzQjtVQUNBLElBQWlDLEtBQUssQ0FBQyxPQUFOLENBQWMsT0FBZCxDQUFqQztZQUFBLEtBQUMsQ0FBQSxVQUFVLENBQUMsT0FBWixHQUFzQixRQUF0Qjs7VUFDQSxLQUFDLENBQUEsY0FBRCxDQUFBLENBQWlCLENBQUMsT0FBbEIsQ0FBMEIsSUFBMUI7VUFDQSxJQUFHLENBQUg7WUFDRSxZQUFBLENBQWEsQ0FBYjttQkFDQSxDQUFBLEdBQUksS0FGTjs7UUFKd0Q7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQTFEO01BUUEsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFkLENBQWtCLGdCQUFsQixFQUFvQyxtQ0FBcEMsRUFBeUUsQ0FBQSxTQUFBLEtBQUE7ZUFBQSxTQUFBO2lCQUN2RSxLQUFDLENBQUEsY0FBRCxDQUFBLENBQWlCLENBQUMsU0FBbEIsQ0FBQTtRQUR1RTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBekU7TUFHQSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQWQsQ0FBa0Isa0JBQWxCLEVBQ0U7UUFBQSxnQ0FBQSxFQUFrQyxDQUFBLFNBQUEsS0FBQTtpQkFBQSxTQUFBO21CQUFHLEtBQUMsQ0FBQSxjQUFELENBQUEsQ0FBaUIsQ0FBQyxNQUFsQixDQUFBO1VBQUg7UUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWxDO1FBQ0EsOEJBQUEsRUFBZ0MsQ0FBQSxTQUFBLEtBQUE7aUJBQUEsU0FBQTttQkFBRyxLQUFDLENBQUEsY0FBRCxDQUFBLENBQWlCLENBQUMsSUFBbEIsQ0FBQTtVQUFIO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQURoQztRQUVBLG9DQUFBLEVBQXNDLENBQUEsU0FBQSxLQUFBO2lCQUFBLFNBQUE7bUJBQUcsS0FBQyxDQUFBLGdCQUFELENBQUEsQ0FBbUIsQ0FBQyxNQUFwQixDQUFBO1VBQUg7UUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBRnRDO09BREY7TUFLQSxJQUFJLENBQUMsU0FBUyxDQUFDLGtCQUFmLENBQWtDLENBQUEsU0FBQSxLQUFBO2VBQUEsU0FBQyxNQUFEO0FBQ2hDLGNBQUE7VUFBQSxVQUFBLEdBQWEsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFYLENBQW1CLE1BQW5CO1VBQ2IsSUFBQSxDQUE0QyxDQUE1QztZQUFDLElBQUssT0FBQSxDQUFRLHNCQUFSLElBQU47O2lCQUNBLENBQUEsQ0FBRSxVQUFGLENBQWEsQ0FBQyxFQUFkLENBQWlCLFdBQWpCLEVBQThCLFNBQUMsS0FBRDtBQUM1QixnQkFBQTtZQUFBLEtBQUEsR0FBUSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0IsNEJBQWhCO1lBQ1IsSUFBYyxtQkFBb0IsQ0FBQSxLQUFBLENBQXBCLEtBQThCLEtBQUssQ0FBQyxLQUFsRDtBQUFBLHFCQUFBOztBQUNBO0FBQUEsaUJBQUEscUNBQUE7O2NBQ0UsSUFBVSxDQUFJLEtBQU0sQ0FBQSxPQUFBLEdBQVEsS0FBUixDQUFwQjtBQUFBLHVCQUFBOztBQURGO21CQUVBLEtBQUMsQ0FBQSxjQUFELENBQUEsQ0FBaUIsQ0FBQyxJQUFsQixDQUFBO1VBTDRCLENBQTlCO1FBSGdDO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUFsQztNQVVBLElBQUcsQ0FBSSxJQUFJLENBQUMsUUFBUSxDQUFDLGlCQUFkLENBQWdDLGNBQWhDLENBQVA7UUFDRSxJQUFJLENBQUMsUUFBUSxDQUFDLGNBQWQsQ0FBNkIsY0FBN0I7UUFDQSxLQUFBLENBQU0sZ0lBQU4sRUFGRjs7TUFNQSxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQVosQ0FBb0IsNEJBQXBCLEVBQWtELENBQUEsU0FBQSxLQUFBO2VBQUEsU0FBQTtVQUNoRCxJQUFBLENBQWMsS0FBQyxDQUFBLFFBQWY7QUFBQSxtQkFBQTs7aUJBQ0EsS0FBQyxDQUFBLFFBQVEsQ0FBQyxRQUFWLEdBQXFCLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQiw0QkFBaEI7UUFGMkI7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBQWxEO01BSUEsaUJBQUEsR0FBb0I7YUFDcEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFaLENBQW9CLDBCQUFwQixFQUFnRCxDQUFBLFNBQUEsS0FBQTtlQUFBLFNBQUE7VUFDOUMsSUFBa0MsaUJBQWxDO1lBQUEsWUFBQSxDQUFhLGlCQUFiLEVBQUE7O2lCQUNBLGlCQUFBLEdBQW9CLFVBQUEsQ0FBVyxDQUFDLFNBQUE7WUFDOUIsS0FBQyxDQUFBLFVBQVUsQ0FBQyxhQUFaLENBQTBCLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQiwwQkFBaEIsQ0FBMkMsQ0FBQyxLQUE1QyxDQUFrRCxHQUFsRCxDQUExQjttQkFDQSxpQkFBQSxHQUFvQjtVQUZVLENBQUQsQ0FBWCxFQUdqQixJQUhpQjtRQUYwQjtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBaEQ7SUFoRFEsQ0F2Q1Y7SUE4RkEsVUFBQSxFQUFZLFNBQUE7TUFDVixJQUFHLHVCQUFIO1FBQ0UsSUFBQyxDQUFBLFVBQVUsQ0FBQyxPQUFaLENBQUE7UUFDQSxJQUFDLENBQUEsVUFBRCxHQUFjLEtBRmhCOztNQUlBLElBQUcscUJBQUg7UUFDRSxJQUFDLENBQUEsUUFBUSxDQUFDLE9BQVYsQ0FBQTtRQUNBLElBQUMsQ0FBQSxRQUFELEdBQVksS0FGZDs7TUFJQSxJQUFHLHdCQUFIO1FBQ0UsSUFBQyxDQUFBLFdBQVcsQ0FBQyxPQUFiLENBQUE7UUFDQSxJQUFDLENBQUEsV0FBRCxHQUFlLEtBRmpCOztNQUlBLElBQUcscUJBQUg7UUFDRSxJQUFDLENBQUEsUUFBUSxDQUFDLE9BQVYsQ0FBQTtRQUNBLElBQUMsQ0FBQSxRQUFELEdBQVksS0FGZDs7TUFJQSxJQUFHLHVCQUFIO1FBQ0UsSUFBQyxDQUFBLFVBQVUsQ0FBQyxPQUFaLENBQUE7UUFDQSxJQUFDLENBQUEsVUFBRCxHQUFjLEtBRmhCOzthQUlBLElBQUMsQ0FBQSxVQUFVLENBQUMsVUFBWixDQUFBO0lBckJVLENBOUZaO0lBcUhBLGNBQUEsRUFBZ0IsU0FBQTtBQUNkLFVBQUE7TUFBQSxJQUFPLHFCQUFQO1FBQ0UsUUFBQSxHQUFZLE9BQUEsQ0FBUSxhQUFSO1FBQ1osSUFBQyxDQUFBLFFBQUQsR0FBWSxJQUFJLFFBQUosQ0FBYSxJQUFDLENBQUEsS0FBZDtRQUNaLElBQUMsQ0FBQSxRQUFRLENBQUMsVUFBVixHQUF1QixJQUFDLENBQUEsV0FIMUI7O2FBSUEsSUFBQyxDQUFBO0lBTGEsQ0FySGhCO0lBNEhBLGdCQUFBLEVBQWtCLFNBQUE7QUFDaEIsVUFBQTtNQUFBLElBQU8sdUJBQVA7UUFDRSxVQUFBLEdBQWEsT0FBQSxDQUFRLGdCQUFSO1FBQ2IsSUFBQyxDQUFBLFVBQUQsR0FBYyxJQUFJLFVBQUosQ0FBZSxJQUFDLENBQUEsS0FBaEIsRUFGaEI7O2FBR0EsSUFBQyxDQUFBO0lBSmUsQ0E1SGxCO0lBa0lBLE9BQUEsRUFBUyxTQUFBO0FBQ1AsVUFBQTtNQUFBLElBQU8scUJBQVA7UUFDRSxhQUFBLEdBQWdCLE9BQUEsQ0FBUSxrQkFBUjtRQUNoQixJQUFDLENBQUEsUUFBRCxHQUFZLElBQUksYUFBSixDQUFBO1FBQ1osSUFBQyxDQUFBLFFBQVEsQ0FBQyxVQUFWLEdBQXVCLElBQUMsQ0FBQTtRQUN4QixJQUFDLENBQUEsUUFBUSxDQUFDLFFBQVYsR0FBcUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLDRCQUFoQixFQUp2Qjs7YUFLQSxJQUFDLENBQUE7SUFOTSxDQWxJVDs7QUFMRiIsInNvdXJjZXNDb250ZW50IjpbIiQgPSBudWxsXG57Q29tcG9zaXRlRGlzcG9zYWJsZX0gPSByZXF1aXJlICdhdG9tJ1xuXG5Nb3VzZUV2ZW50V2hpY2hEaWN0ID0ge1wibGVmdCBjbGlja1wiOiAxLCBcIm1pZGRsZSBjbGlja1wiOiAyLCBcInJpZ2h0IGNsaWNrXCI6IDN9XG5tb2R1bGUuZXhwb3J0cyA9XG4gIGRpc3Bvc2FibGU6IG51bGxcblxuICBjb25maWc6XG4gICAgZGlzYWJsZUNvbXBsZXRlOlxuICAgICAgdGl0bGU6ICdEaXNhYmxlIGF1dG8gY29tcGxldGUnXG4gICAgICB0eXBlOiAnYm9vbGVhbidcbiAgICAgIGRlZmF1bHQ6IGZhbHNlXG4gICAgYXV0b0J1aWxkVGFnc1doZW5BY3RpdmU6XG4gICAgICB0aXRsZTogJ0F1dG9tYXRpY2FsbHkgcmVidWlsZCB0YWdzJ1xuICAgICAgZGVzY3JpcHRpb246ICdSZWJ1aWxkIHRhZ3MgZmlsZSBlYWNoIHRpbWUgYSBwcm9qZWN0IHBhdGggY2hhbmdlcydcbiAgICAgIHR5cGU6ICdib29sZWFuJ1xuICAgICAgZGVmYXVsdDogZmFsc2VcbiAgICBidWlsZFRpbWVvdXQ6XG4gICAgICB0aXRsZTogJ0J1aWxkIHRpbWVvdXQnXG4gICAgICBkZXNjcmlwdGlvbjogJ1RpbWUgKGluIG1pbGxpc2Vjb25kcykgdG8gd2FpdCBmb3IgYSB0YWdzIHJlYnVpbGQgdG8gZmluaXNoJ1xuICAgICAgdHlwZTogJ2ludGVnZXInXG4gICAgICBkZWZhdWx0OiAxMDAwMFxuICAgIGNtZDpcbiAgICAgIHR5cGU6ICdzdHJpbmcnXG4gICAgICBkZWZhdWx0OiBcIlwiXG4gICAgY21kQXJnczpcbiAgICAgIGRlc2NyaXB0aW9uOiAnQWRkIHNwZWNpZmllZCBjdGFnIGNvbW1hbmQgYXJncyBsaWtlOiAtLWV4Y2x1ZGU9bGliIC0tZXhjbHVkZT0qLmpzJ1xuICAgICAgdHlwZTogJ3N0cmluZydcbiAgICAgIGRlZmF1bHQ6IFwiXCJcbiAgICBleHRyYVRhZ0ZpbGVzOlxuICAgICAgZGVzY3JpcHRpb246ICdBZGQgc3BlY2lmaWVkIHRhZ0ZpbGVzLiAoTWFrZSBzdXJlIHlvdSB0YWcgZmlsZSBnZW5lcmF0ZSB3aXRoIC0tZmllbGRzPStLU24pJ1xuICAgICAgdHlwZTogJ3N0cmluZydcbiAgICAgIGRlZmF1bHQ6IFwiXCJcbiAgICBHb3RvU3ltYm9sS2V5OlxuICAgICAgZGVzY3JpcHRpb246ICdjb21iaW5lIGJpbmRpbmdzOiBhbHQsIGN0cmwsIG1ldGEsIHNoaWZ0J1xuICAgICAgdHlwZTogJ2FycmF5J1xuICAgICAgZGVmYXVsdDogW1wiYWx0XCJdXG4gICAgR290b1N5bWJvbENsaWNrOlxuICAgICAgdHlwZTogJ3N0cmluZydcbiAgICAgIGRlZmF1bHQ6IFwibGVmdCBjbGlja1wiXG4gICAgICBlbnVtOiBbXCJsZWZ0IGNsaWNrXCIsIFwibWlkZGxlIGNsaWNrXCIsIFwicmlnaHQgY2xpY2tcIl1cblxuICBwcm92aWRlcjogbnVsbFxuXG4gIGFjdGl2YXRlOiAtPlxuICAgIEBzdGFjayA9IFtdXG5cbiAgICBAY3RhZ3NDYWNoZSA9IHJlcXVpcmUgXCIuL2N0YWdzLWNhY2hlXCJcblxuICAgIEBjdGFnc0NhY2hlLmFjdGl2YXRlKClcblxuICAgIEBjdGFnc0NhY2hlLmluaXRUYWdzKGF0b20ucHJvamVjdC5nZXRQYXRocygpLCBhdG9tLmNvbmZpZy5nZXQoJ2F0b20tY3RhZ3MuYXV0b0J1aWxkVGFnc1doZW5BY3RpdmUnKSlcbiAgICBAZGlzcG9zYWJsZSA9IGF0b20ucHJvamVjdC5vbkRpZENoYW5nZVBhdGhzIChwYXRocyk9PlxuICAgICAgQGN0YWdzQ2FjaGUuaW5pdFRhZ3MocGF0aHMsIGF0b20uY29uZmlnLmdldCgnYXRvbS1jdGFncy5hdXRvQnVpbGRUYWdzV2hlbkFjdGl2ZScpKVxuXG4gICAgYXRvbS5jb21tYW5kcy5hZGQgJ2F0b20td29ya3NwYWNlJywgJ2F0b20tY3RhZ3M6cmVidWlsZCcsIChlLCBjbWRBcmdzKT0+XG4gICAgICBjb25zb2xlLmVycm9yIFwicmVidWlsZDogXCIsIGVcbiAgICAgIEBjdGFnc0NhY2hlLmNtZEFyZ3MgPSBjbWRBcmdzIGlmIEFycmF5LmlzQXJyYXkoY21kQXJncylcbiAgICAgIEBjcmVhdGVGaWxlVmlldygpLnJlYnVpbGQodHJ1ZSlcbiAgICAgIGlmIHRcbiAgICAgICAgY2xlYXJUaW1lb3V0KHQpXG4gICAgICAgIHQgPSBudWxsXG5cbiAgICBhdG9tLmNvbW1hbmRzLmFkZCAnYXRvbS13b3Jrc3BhY2UnLCAnYXRvbS1jdGFnczp0b2dnbGUtcHJvamVjdC1zeW1ib2xzJywgPT5cbiAgICAgIEBjcmVhdGVGaWxlVmlldygpLnRvZ2dsZUFsbCgpXG5cbiAgICBhdG9tLmNvbW1hbmRzLmFkZCAnYXRvbS10ZXh0LWVkaXRvcicsXG4gICAgICAnYXRvbS1jdGFnczp0b2dnbGUtZmlsZS1zeW1ib2xzJzogPT4gQGNyZWF0ZUZpbGVWaWV3KCkudG9nZ2xlKClcbiAgICAgICdhdG9tLWN0YWdzOmdvLXRvLWRlY2xhcmF0aW9uJzogPT4gQGNyZWF0ZUZpbGVWaWV3KCkuZ290bygpXG4gICAgICAnYXRvbS1jdGFnczpyZXR1cm4tZnJvbS1kZWNsYXJhdGlvbic6ID0+IEBjcmVhdGVHb0JhY2tWaWV3KCkudG9nZ2xlKClcblxuICAgIGF0b20ud29ya3NwYWNlLm9ic2VydmVUZXh0RWRpdG9ycyAoZWRpdG9yKSA9PlxuICAgICAgZWRpdG9yVmlldyA9IGF0b20udmlld3MuZ2V0VmlldyhlZGl0b3IpXG4gICAgICB7JH0gPSByZXF1aXJlICdhdG9tLXNwYWNlLXBlbi12aWV3cycgdW5sZXNzICRcbiAgICAgICQoZWRpdG9yVmlldykub24gJ21vdXNlZG93bicsIChldmVudCkgPT5cbiAgICAgICAgd2hpY2ggPSBhdG9tLmNvbmZpZy5nZXQoJ2F0b20tY3RhZ3MuR290b1N5bWJvbENsaWNrJylcbiAgICAgICAgcmV0dXJuIHVubGVzcyBNb3VzZUV2ZW50V2hpY2hEaWN0W3doaWNoXSA9PSBldmVudC53aGljaFxuICAgICAgICBmb3Iga2V5TmFtZSBpbiBhdG9tLmNvbmZpZy5nZXQoJ2F0b20tY3RhZ3MuR290b1N5bWJvbEtleScpXG4gICAgICAgICAgcmV0dXJuIGlmIG5vdCBldmVudFtrZXlOYW1lK1wiS2V5XCJdXG4gICAgICAgIEBjcmVhdGVGaWxlVmlldygpLmdvdG8oKVxuXG4gICAgaWYgbm90IGF0b20ucGFja2FnZXMuaXNQYWNrYWdlRGlzYWJsZWQoXCJzeW1ib2xzLXZpZXdcIilcbiAgICAgIGF0b20ucGFja2FnZXMuZGlzYWJsZVBhY2thZ2UoXCJzeW1ib2xzLXZpZXdcIilcbiAgICAgIGFsZXJ0IFwiV2FybmluZyBmcm9tIGF0b20tY3RhZ3M6XG4gICAgICAgICAgICAgIGF0b20tY3RhZ3MgcmVwbGFjZXMgYW5kIGVuaGFuY2VzIHRoZSBzeW1ib2xzLXZpZXcgcGFja2FnZS5cbiAgICAgICAgICAgICAgVGhlcmVmb3JlLCBzeW1ib2xzLXZpZXcgaGFzIGJlZW4gZGlzYWJsZWQuXCJcblxuICAgIGF0b20uY29uZmlnLm9ic2VydmUgJ2F0b20tY3RhZ3MuZGlzYWJsZUNvbXBsZXRlJywgPT5cbiAgICAgIHJldHVybiB1bmxlc3MgQHByb3ZpZGVyXG4gICAgICBAcHJvdmlkZXIuZGlzYWJsZWQgPSBhdG9tLmNvbmZpZy5nZXQoJ2F0b20tY3RhZ3MuZGlzYWJsZUNvbXBsZXRlJylcblxuICAgIGluaXRFeHRyYVRhZ3NUaW1lID0gbnVsbFxuICAgIGF0b20uY29uZmlnLm9ic2VydmUgJ2F0b20tY3RhZ3MuZXh0cmFUYWdGaWxlcycsID0+XG4gICAgICBjbGVhclRpbWVvdXQgaW5pdEV4dHJhVGFnc1RpbWUgaWYgaW5pdEV4dHJhVGFnc1RpbWVcbiAgICAgIGluaXRFeHRyYVRhZ3NUaW1lID0gc2V0VGltZW91dCgoPT5cbiAgICAgICAgQGN0YWdzQ2FjaGUuaW5pdEV4dHJhVGFncyhhdG9tLmNvbmZpZy5nZXQoJ2F0b20tY3RhZ3MuZXh0cmFUYWdGaWxlcycpLnNwbGl0KFwiIFwiKSlcbiAgICAgICAgaW5pdEV4dHJhVGFnc1RpbWUgPSBudWxsXG4gICAgICApLCAxMDAwKVxuXG4gIGRlYWN0aXZhdGU6IC0+XG4gICAgaWYgQGRpc3Bvc2FibGU/XG4gICAgICBAZGlzcG9zYWJsZS5kaXNwb3NlKClcbiAgICAgIEBkaXNwb3NhYmxlID0gbnVsbFxuXG4gICAgaWYgQGZpbGVWaWV3P1xuICAgICAgQGZpbGVWaWV3LmRlc3Ryb3koKVxuICAgICAgQGZpbGVWaWV3ID0gbnVsbFxuXG4gICAgaWYgQHByb2plY3RWaWV3P1xuICAgICAgQHByb2plY3RWaWV3LmRlc3Ryb3koKVxuICAgICAgQHByb2plY3RWaWV3ID0gbnVsbFxuXG4gICAgaWYgQGdvVG9WaWV3P1xuICAgICAgQGdvVG9WaWV3LmRlc3Ryb3koKVxuICAgICAgQGdvVG9WaWV3ID0gbnVsbFxuXG4gICAgaWYgQGdvQmFja1ZpZXc/XG4gICAgICBAZ29CYWNrVmlldy5kZXN0cm95KClcbiAgICAgIEBnb0JhY2tWaWV3ID0gbnVsbFxuXG4gICAgQGN0YWdzQ2FjaGUuZGVhY3RpdmF0ZSgpXG5cbiAgY3JlYXRlRmlsZVZpZXc6IC0+XG4gICAgdW5sZXNzIEBmaWxlVmlldz9cbiAgICAgIEZpbGVWaWV3ICA9IHJlcXVpcmUgJy4vZmlsZS12aWV3J1xuICAgICAgQGZpbGVWaWV3ID0gbmV3IEZpbGVWaWV3KEBzdGFjaylcbiAgICAgIEBmaWxlVmlldy5jdGFnc0NhY2hlID0gQGN0YWdzQ2FjaGVcbiAgICBAZmlsZVZpZXdcblxuICBjcmVhdGVHb0JhY2tWaWV3OiAtPlxuICAgIHVubGVzcyBAZ29CYWNrVmlldz9cbiAgICAgIEdvQmFja1ZpZXcgPSByZXF1aXJlICcuL2dvLWJhY2stdmlldydcbiAgICAgIEBnb0JhY2tWaWV3ID0gbmV3IEdvQmFja1ZpZXcoQHN0YWNrKVxuICAgIEBnb0JhY2tWaWV3XG5cbiAgcHJvdmlkZTogLT5cbiAgICB1bmxlc3MgQHByb3ZpZGVyP1xuICAgICAgQ3RhZ3NQcm92aWRlciA9IHJlcXVpcmUgJy4vY3RhZ3MtcHJvdmlkZXInXG4gICAgICBAcHJvdmlkZXIgPSBuZXcgQ3RhZ3NQcm92aWRlcigpXG4gICAgICBAcHJvdmlkZXIuY3RhZ3NDYWNoZSA9IEBjdGFnc0NhY2hlXG4gICAgICBAcHJvdmlkZXIuZGlzYWJsZWQgPSBhdG9tLmNvbmZpZy5nZXQoJ2F0b20tY3RhZ3MuZGlzYWJsZUNvbXBsZXRlJylcbiAgICBAcHJvdmlkZXJcbiJdfQ==
