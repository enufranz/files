(function() {
  var Tags, es;

  Tags = require(process.resourcesPath + '/app.asar.unpacked/node_modules/ctags/build/Release/ctags.node').Tags;

  es = require('event-stream');

  exports.findTags = function(tagsFilePath, tag, options, callback) {
    var caseInsensitive, partialMatch, ref, tagsWrapper;
    if (typeof tagsFilePath !== 'string') {
      throw new TypeError('tagsFilePath must be a string');
    }
    if (typeof tag !== 'string') {
      throw new TypeError('tag must be a string');
    }
    if (typeof options === 'function') {
      callback = options;
      options = null;
    }
    ref = options != null ? options : {}, partialMatch = ref.partialMatch, caseInsensitive = ref.caseInsensitive;
    tagsWrapper = new Tags(tagsFilePath);
    tagsWrapper.findTags(tag, partialMatch, caseInsensitive, function(error, tags) {
      tagsWrapper.end();
      return typeof callback === "function" ? callback(error, tags) : void 0;
    });
    return void 0;
  };

  exports.createReadStream = function(tagsFilePath, options) {
    var chunkSize, tagsWrapper;
    if (options == null) {
      options = {};
    }
    if (typeof tagsFilePath !== 'string') {
      throw new TypeError('tagsFilePath must be a string');
    }
    chunkSize = options.chunkSize;
    if (typeof chunkSize !== 'number') {
      chunkSize = 100;
    }
    tagsWrapper = new Tags(tagsFilePath);
    return es.readable(function(count, callback) {
      if (!tagsWrapper.exists()) {
        return callback(new Error("Tags file could not be opened: " + tagsFilePath));
      }
      return tagsWrapper.getTags(chunkSize, (function(_this) {
        return function(error, tags) {
          if ((error != null) || tags.length === 0) {
            tagsWrapper.end();
          }
          callback(error, tags);
          if ((error != null) || tags.length === 0) {
            return _this.emit('end');
          }
        };
      })(this));
    });
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZmlsZTovLy9DOi9Vc2Vycy9mbGlzei8uYXRvbS9wYWNrYWdlcy9hdG9tLWN0YWdzL25vZGVfbW9kdWxlcy9jdGFncy9zcmMvY3RhZ3MuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsTUFBQTs7RUFBQyxPQUFRLE9BQUEsQ0FBUSxPQUFPLENBQUMsYUFBUixHQUF3QixnRUFBaEM7O0VBQ1QsRUFBQSxHQUFLLE9BQUEsQ0FBUSxjQUFSOztFQUVMLE9BQU8sQ0FBQyxRQUFSLEdBQW1CLFNBQUMsWUFBRCxFQUFlLEdBQWYsRUFBb0IsT0FBcEIsRUFBNkIsUUFBN0I7QUFDakIsUUFBQTtJQUFBLElBQU8sT0FBTyxZQUFQLEtBQXVCLFFBQTlCO0FBQ0UsWUFBTSxJQUFJLFNBQUosQ0FBYywrQkFBZCxFQURSOztJQUdBLElBQU8sT0FBTyxHQUFQLEtBQWMsUUFBckI7QUFDRSxZQUFNLElBQUksU0FBSixDQUFjLHNCQUFkLEVBRFI7O0lBR0EsSUFBRyxPQUFPLE9BQVAsS0FBa0IsVUFBckI7TUFDRSxRQUFBLEdBQVc7TUFDWCxPQUFBLEdBQVUsS0FGWjs7SUFJQSx3QkFBa0MsVUFBVSxFQUE1QyxFQUFDLCtCQUFELEVBQWU7SUFFZixXQUFBLEdBQWMsSUFBSSxJQUFKLENBQVMsWUFBVDtJQUNkLFdBQVcsQ0FBQyxRQUFaLENBQXFCLEdBQXJCLEVBQTBCLFlBQTFCLEVBQXdDLGVBQXhDLEVBQXlELFNBQUMsS0FBRCxFQUFRLElBQVI7TUFDdkQsV0FBVyxDQUFDLEdBQVosQ0FBQTs4Q0FDQSxTQUFVLE9BQU87SUFGc0MsQ0FBekQ7V0FJQTtFQWxCaUI7O0VBb0JuQixPQUFPLENBQUMsZ0JBQVIsR0FBMkIsU0FBQyxZQUFELEVBQWUsT0FBZjtBQUN6QixRQUFBOztNQUR3QyxVQUFROztJQUNoRCxJQUFPLE9BQU8sWUFBUCxLQUF1QixRQUE5QjtBQUNFLFlBQU0sSUFBSSxTQUFKLENBQWMsK0JBQWQsRUFEUjs7SUFHQyxZQUFhO0lBQ2QsSUFBbUIsT0FBTyxTQUFQLEtBQXNCLFFBQXpDO01BQUEsU0FBQSxHQUFZLElBQVo7O0lBRUEsV0FBQSxHQUFjLElBQUksSUFBSixDQUFTLFlBQVQ7V0FDZCxFQUFFLENBQUMsUUFBSCxDQUFZLFNBQUMsS0FBRCxFQUFRLFFBQVI7TUFDVixJQUFBLENBQU8sV0FBVyxDQUFDLE1BQVosQ0FBQSxDQUFQO0FBQ0UsZUFBTyxRQUFBLENBQVMsSUFBSSxLQUFKLENBQVUsaUNBQUEsR0FBa0MsWUFBNUMsQ0FBVCxFQURUOzthQUdBLFdBQVcsQ0FBQyxPQUFaLENBQW9CLFNBQXBCLEVBQStCLENBQUEsU0FBQSxLQUFBO2VBQUEsU0FBQyxLQUFELEVBQVEsSUFBUjtVQUM3QixJQUFxQixlQUFBLElBQVUsSUFBSSxDQUFDLE1BQUwsS0FBZSxDQUE5QztZQUFBLFdBQVcsQ0FBQyxHQUFaLENBQUEsRUFBQTs7VUFDQSxRQUFBLENBQVMsS0FBVCxFQUFnQixJQUFoQjtVQUNBLElBQWdCLGVBQUEsSUFBVSxJQUFJLENBQUMsTUFBTCxLQUFlLENBQXpDO21CQUFBLEtBQUMsQ0FBQSxJQUFELENBQU0sS0FBTixFQUFBOztRQUg2QjtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBL0I7SUFKVSxDQUFaO0VBUnlCO0FBdkIzQiIsInNvdXJjZXNDb250ZW50IjpbIntUYWdzfSA9IHJlcXVpcmUocHJvY2Vzcy5yZXNvdXJjZXNQYXRoICsgJy9hcHAuYXNhci51bnBhY2tlZC9ub2RlX21vZHVsZXMvY3RhZ3MvYnVpbGQvUmVsZWFzZS9jdGFncy5ub2RlJylcbmVzID0gcmVxdWlyZSAnZXZlbnQtc3RyZWFtJ1xuXG5leHBvcnRzLmZpbmRUYWdzID0gKHRhZ3NGaWxlUGF0aCwgdGFnLCBvcHRpb25zLCBjYWxsYmFjaykgLT5cbiAgdW5sZXNzIHR5cGVvZiB0YWdzRmlsZVBhdGggaXMgJ3N0cmluZydcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCd0YWdzRmlsZVBhdGggbXVzdCBiZSBhIHN0cmluZycpXG5cbiAgdW5sZXNzIHR5cGVvZiB0YWcgaXMgJ3N0cmluZydcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCd0YWcgbXVzdCBiZSBhIHN0cmluZycpXG5cbiAgaWYgdHlwZW9mIG9wdGlvbnMgaXMgJ2Z1bmN0aW9uJ1xuICAgIGNhbGxiYWNrID0gb3B0aW9uc1xuICAgIG9wdGlvbnMgPSBudWxsXG5cbiAge3BhcnRpYWxNYXRjaCwgY2FzZUluc2Vuc2l0aXZlfSA9IG9wdGlvbnMgPyB7fVxuXG4gIHRhZ3NXcmFwcGVyID0gbmV3IFRhZ3ModGFnc0ZpbGVQYXRoKVxuICB0YWdzV3JhcHBlci5maW5kVGFncyB0YWcsIHBhcnRpYWxNYXRjaCwgY2FzZUluc2Vuc2l0aXZlLCAoZXJyb3IsIHRhZ3MpIC0+XG4gICAgdGFnc1dyYXBwZXIuZW5kKClcbiAgICBjYWxsYmFjaz8oZXJyb3IsIHRhZ3MpXG5cbiAgdW5kZWZpbmVkXG5cbmV4cG9ydHMuY3JlYXRlUmVhZFN0cmVhbSA9ICh0YWdzRmlsZVBhdGgsIG9wdGlvbnM9e30pIC0+XG4gIHVubGVzcyB0eXBlb2YgdGFnc0ZpbGVQYXRoIGlzICdzdHJpbmcnXG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcigndGFnc0ZpbGVQYXRoIG11c3QgYmUgYSBzdHJpbmcnKVxuXG4gIHtjaHVua1NpemV9ID0gb3B0aW9uc1xuICBjaHVua1NpemUgPSAxMDAgaWYgdHlwZW9mIGNodW5rU2l6ZSBpc250ICdudW1iZXInXG5cbiAgdGFnc1dyYXBwZXIgPSBuZXcgVGFncyh0YWdzRmlsZVBhdGgpXG4gIGVzLnJlYWRhYmxlIChjb3VudCwgY2FsbGJhY2spIC0+XG4gICAgdW5sZXNzIHRhZ3NXcmFwcGVyLmV4aXN0cygpXG4gICAgICByZXR1cm4gY2FsbGJhY2sobmV3IEVycm9yKFwiVGFncyBmaWxlIGNvdWxkIG5vdCBiZSBvcGVuZWQ6ICN7dGFnc0ZpbGVQYXRofVwiKSlcblxuICAgIHRhZ3NXcmFwcGVyLmdldFRhZ3MgY2h1bmtTaXplLCAoZXJyb3IsIHRhZ3MpID0+XG4gICAgICB0YWdzV3JhcHBlci5lbmQoKSBpZiBlcnJvcj8gb3IgdGFncy5sZW5ndGggaXMgMFxuICAgICAgY2FsbGJhY2soZXJyb3IsIHRhZ3MpXG4gICAgICBAZW1pdCgnZW5kJykgaWYgZXJyb3I/IG9yIHRhZ3MubGVuZ3RoIGlzIDBcbiJdfQ==
