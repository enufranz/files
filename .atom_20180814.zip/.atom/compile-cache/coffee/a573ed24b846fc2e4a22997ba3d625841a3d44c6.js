(function() {
  var TagGenerator, ctags, fs, getTagsFile, matchOpt, path;

  TagGenerator = require('./tag-generator');

  ctags = require('ctags');

  fs = require("fs");

  path = require("path");

  getTagsFile = function(directoryPath) {
    var tagsFile;
    tagsFile = path.join(directoryPath, ".tags");
    if (fs.existsSync(tagsFile)) {
      return tagsFile;
    }
  };

  matchOpt = {
    matchBase: true
  };

  module.exports = {
    activate: function() {
      this.cachedTags = {};
      return this.extraTags = {};
    },
    deactivate: function() {
      return this.cachedTags = null;
    },
    initTags: function(paths, auto) {
      var i, len, p, results, tagsFile;
      if (paths.length === 0) {
        return;
      }
      this.cachedTags = {};
      results = [];
      for (i = 0, len = paths.length; i < len; i++) {
        p = paths[i];
        tagsFile = getTagsFile(p);
        if (tagsFile) {
          results.push(this.readTags(tagsFile, this.cachedTags));
        } else {
          if (auto) {
            results.push(this.generateTags(p));
          } else {
            results.push(void 0);
          }
        }
      }
      return results;
    },
    initExtraTags: function(paths) {
      var i, len, p, results;
      this.extraTags = {};
      results = [];
      for (i = 0, len = paths.length; i < len; i++) {
        p = paths[i];
        p = p.trim();
        if (!p) {
          continue;
        }
        results.push(this.readTags(p, this.extraTags));
      }
      return results;
    },
    readTags: function(p, container, callback) {
      var startTime, stream;
      console.log("[atom-ctags:readTags] " + p + " start...");
      startTime = Date.now();
      stream = ctags.createReadStream(p);
      stream.on('error', function(error) {
        return console.error('atom-ctags: ', error);
      });
      stream.on('data', function(tags) {
        var data, i, len, results, tag;
        results = [];
        for (i = 0, len = tags.length; i < len; i++) {
          tag = tags[i];
          if (!tag.pattern) {
            continue;
          }
          data = container[tag.file];
          if (!data) {
            data = [];
            container[tag.file] = data;
          }
          results.push(data.push(tag));
        }
        return results;
      });
      return stream.on('end', function() {
        console.log("[atom-ctags:readTags] " + p + " cost: " + (Date.now() - startTime) + "ms");
        return typeof callback === "function" ? callback() : void 0;
      });
    },
    findTags: function(prefix, options) {
      var tags;
      tags = [];
      if (this.findOf(this.cachedTags, tags, prefix, options)) {
        return tags;
      }
      if (this.findOf(this.extraTags, tags, prefix, options)) {
        return tags;
      }
      if (tags.length === 0) {
        console.warn("[atom-ctags:findTags] tags empty, did you RebuildTags or set extraTagFiles?");
      }
      return tags;
    },
    findOf: function(source, tags, prefix, options) {
      var i, key, len, tag, value;
      for (key in source) {
        value = source[key];
        for (i = 0, len = value.length; i < len; i++) {
          tag = value[i];
          if ((options != null ? options.partialMatch : void 0) && tag.name.indexOf(prefix) === 0) {
            tags.push(tag);
          } else if (tag.name === prefix) {
            tags.push(tag);
          }
          if ((options != null ? options.maxItems : void 0) && tags.length === options.maxItems) {
            return true;
          }
        }
      }
      return false;
    },
    generateTags: function(p, isAppend, callback) {
      var cmdArgs, startTime;
      delete this.cachedTags[p];
      startTime = Date.now();
      console.log("[atom-ctags:rebuild] start @" + p + "@ tags...");
      cmdArgs = atom.config.get("atom-ctags.cmdArgs");
      if (cmdArgs) {
        cmdArgs = cmdArgs.split(" ");
      }
      return TagGenerator(p, isAppend, this.cmdArgs || cmdArgs, (function(_this) {
        return function(tagpath) {
          console.log("[atom-ctags:rebuild] command done @" + p + "@ tags. cost: " + (Date.now() - startTime) + "ms");
          startTime = Date.now();
          return _this.readTags(tagpath, _this.cachedTags, callback);
        };
      })(this));
    },
    getOrCreateTags: function(filePath, callback) {
      var tags;
      tags = this.cachedTags[filePath];
      if (tags) {
        return typeof callback === "function" ? callback(tags) : void 0;
      }
      return this.generateTags(filePath, true, (function(_this) {
        return function() {
          tags = _this.cachedTags[filePath];
          return typeof callback === "function" ? callback(tags) : void 0;
        };
      })(this));
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZmlsZTovLy9DOi9Vc2Vycy9mbGlzei8uYXRvbS9wYWNrYWdlcy9hdG9tLWN0YWdzL2xpYi9jdGFncy1jYWNoZS5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7QUFBQSxNQUFBOztFQUFBLFlBQUEsR0FBZSxPQUFBLENBQVEsaUJBQVI7O0VBQ2YsS0FBQSxHQUFRLE9BQUEsQ0FBUSxPQUFSOztFQUNSLEVBQUEsR0FBSyxPQUFBLENBQVEsSUFBUjs7RUFDTCxJQUFBLEdBQU8sT0FBQSxDQUFRLE1BQVI7O0VBRVAsV0FBQSxHQUFjLFNBQUMsYUFBRDtBQUNaLFFBQUE7SUFBQSxRQUFBLEdBQVcsSUFBSSxDQUFDLElBQUwsQ0FBVSxhQUFWLEVBQXlCLE9BQXpCO0lBQ1gsSUFBbUIsRUFBRSxDQUFDLFVBQUgsQ0FBYyxRQUFkLENBQW5CO0FBQUEsYUFBTyxTQUFQOztFQUZZOztFQUlkLFFBQUEsR0FBVztJQUFDLFNBQUEsRUFBVyxJQUFaOzs7RUFDWCxNQUFNLENBQUMsT0FBUCxHQUNFO0lBQUEsUUFBQSxFQUFVLFNBQUE7TUFDUixJQUFDLENBQUEsVUFBRCxHQUFjO2FBQ2QsSUFBQyxDQUFBLFNBQUQsR0FBYTtJQUZMLENBQVY7SUFJQSxVQUFBLEVBQVksU0FBQTthQUNWLElBQUMsQ0FBQSxVQUFELEdBQWM7SUFESixDQUpaO0lBT0EsUUFBQSxFQUFVLFNBQUMsS0FBRCxFQUFRLElBQVI7QUFDUixVQUFBO01BQUEsSUFBVSxLQUFLLENBQUMsTUFBTixLQUFnQixDQUExQjtBQUFBLGVBQUE7O01BQ0EsSUFBQyxDQUFBLFVBQUQsR0FBYztBQUNkO1dBQUEsdUNBQUE7O1FBQ0UsUUFBQSxHQUFXLFdBQUEsQ0FBWSxDQUFaO1FBQ1gsSUFBRyxRQUFIO3VCQUNFLElBQUMsQ0FBQSxRQUFELENBQVUsUUFBVixFQUFvQixJQUFDLENBQUEsVUFBckIsR0FERjtTQUFBLE1BQUE7VUFHRSxJQUFvQixJQUFwQjt5QkFBQSxJQUFDLENBQUEsWUFBRCxDQUFjLENBQWQsR0FBQTtXQUFBLE1BQUE7aUNBQUE7V0FIRjs7QUFGRjs7SUFIUSxDQVBWO0lBaUJBLGFBQUEsRUFBZSxTQUFDLEtBQUQ7QUFDYixVQUFBO01BQUEsSUFBQyxDQUFBLFNBQUQsR0FBYTtBQUNiO1dBQUEsdUNBQUE7O1FBQ0UsQ0FBQSxHQUFJLENBQUMsQ0FBQyxJQUFGLENBQUE7UUFDSixJQUFBLENBQWdCLENBQWhCO0FBQUEsbUJBQUE7O3FCQUNBLElBQUMsQ0FBQSxRQUFELENBQVUsQ0FBVixFQUFhLElBQUMsQ0FBQSxTQUFkO0FBSEY7O0lBRmEsQ0FqQmY7SUF3QkEsUUFBQSxFQUFVLFNBQUMsQ0FBRCxFQUFJLFNBQUosRUFBZSxRQUFmO0FBQ1IsVUFBQTtNQUFBLE9BQU8sQ0FBQyxHQUFSLENBQVksd0JBQUEsR0FBeUIsQ0FBekIsR0FBMkIsV0FBdkM7TUFDQSxTQUFBLEdBQVksSUFBSSxDQUFDLEdBQUwsQ0FBQTtNQUVaLE1BQUEsR0FBUyxLQUFLLENBQUMsZ0JBQU4sQ0FBdUIsQ0FBdkI7TUFFVCxNQUFNLENBQUMsRUFBUCxDQUFVLE9BQVYsRUFBbUIsU0FBQyxLQUFEO2VBQ2pCLE9BQU8sQ0FBQyxLQUFSLENBQWMsY0FBZCxFQUE4QixLQUE5QjtNQURpQixDQUFuQjtNQUdBLE1BQU0sQ0FBQyxFQUFQLENBQVUsTUFBVixFQUFrQixTQUFDLElBQUQ7QUFDaEIsWUFBQTtBQUFBO2FBQUEsc0NBQUE7O1VBQ0UsSUFBQSxDQUFnQixHQUFHLENBQUMsT0FBcEI7QUFBQSxxQkFBQTs7VUFDQSxJQUFBLEdBQU8sU0FBVSxDQUFBLEdBQUcsQ0FBQyxJQUFKO1VBQ2pCLElBQUcsQ0FBSSxJQUFQO1lBQ0UsSUFBQSxHQUFPO1lBQ1AsU0FBVSxDQUFBLEdBQUcsQ0FBQyxJQUFKLENBQVYsR0FBc0IsS0FGeEI7O3VCQUdBLElBQUksQ0FBQyxJQUFMLENBQVUsR0FBVjtBQU5GOztNQURnQixDQUFsQjthQVFBLE1BQU0sQ0FBQyxFQUFQLENBQVUsS0FBVixFQUFpQixTQUFBO1FBQ2YsT0FBTyxDQUFDLEdBQVIsQ0FBWSx3QkFBQSxHQUF5QixDQUF6QixHQUEyQixTQUEzQixHQUFtQyxDQUFDLElBQUksQ0FBQyxHQUFMLENBQUEsQ0FBQSxHQUFhLFNBQWQsQ0FBbkMsR0FBMkQsSUFBdkU7Z0RBQ0E7TUFGZSxDQUFqQjtJQWpCUSxDQXhCVjtJQThDQSxRQUFBLEVBQVUsU0FBQyxNQUFELEVBQVMsT0FBVDtBQUNSLFVBQUE7TUFBQSxJQUFBLEdBQU87TUFDUCxJQUFlLElBQUMsQ0FBQSxNQUFELENBQVEsSUFBQyxDQUFBLFVBQVQsRUFBcUIsSUFBckIsRUFBMkIsTUFBM0IsRUFBbUMsT0FBbkMsQ0FBZjtBQUFBLGVBQU8sS0FBUDs7TUFDQSxJQUFlLElBQUMsQ0FBQSxNQUFELENBQVEsSUFBQyxDQUFBLFNBQVQsRUFBb0IsSUFBcEIsRUFBMEIsTUFBMUIsRUFBa0MsT0FBbEMsQ0FBZjtBQUFBLGVBQU8sS0FBUDs7TUFHQSxJQUErRixJQUFJLENBQUMsTUFBTCxLQUFlLENBQTlHO1FBQUEsT0FBTyxDQUFDLElBQVIsQ0FBYSw2RUFBYixFQUFBOztBQUNBLGFBQU87SUFQQyxDQTlDVjtJQXVEQSxNQUFBLEVBQVEsU0FBQyxNQUFELEVBQVMsSUFBVCxFQUFlLE1BQWYsRUFBdUIsT0FBdkI7QUFDTixVQUFBO0FBQUEsV0FBQSxhQUFBOztBQUNFLGFBQUEsdUNBQUE7O1VBQ0UsdUJBQUcsT0FBTyxDQUFFLHNCQUFULElBQTBCLEdBQUcsQ0FBQyxJQUFJLENBQUMsT0FBVCxDQUFpQixNQUFqQixDQUFBLEtBQTRCLENBQXpEO1lBQ0ksSUFBSSxDQUFDLElBQUwsQ0FBVSxHQUFWLEVBREo7V0FBQSxNQUVLLElBQUcsR0FBRyxDQUFDLElBQUosS0FBWSxNQUFmO1lBQ0gsSUFBSSxDQUFDLElBQUwsQ0FBVSxHQUFWLEVBREc7O1VBRUwsdUJBQWUsT0FBTyxDQUFFLGtCQUFULElBQXNCLElBQUksQ0FBQyxNQUFMLEtBQWUsT0FBTyxDQUFDLFFBQTVEO0FBQUEsbUJBQU8sS0FBUDs7QUFMRjtBQURGO0FBT0EsYUFBTztJQVJELENBdkRSO0lBaUVBLFlBQUEsRUFBYSxTQUFDLENBQUQsRUFBSSxRQUFKLEVBQWMsUUFBZDtBQUNYLFVBQUE7TUFBQSxPQUFPLElBQUMsQ0FBQSxVQUFXLENBQUEsQ0FBQTtNQUVuQixTQUFBLEdBQVksSUFBSSxDQUFDLEdBQUwsQ0FBQTtNQUNaLE9BQU8sQ0FBQyxHQUFSLENBQVksOEJBQUEsR0FBK0IsQ0FBL0IsR0FBaUMsV0FBN0M7TUFFQSxPQUFBLEdBQVUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLG9CQUFoQjtNQUNWLElBQWdDLE9BQWhDO1FBQUEsT0FBQSxHQUFVLE9BQU8sQ0FBQyxLQUFSLENBQWMsR0FBZCxFQUFWOzthQUVBLFlBQUEsQ0FBYSxDQUFiLEVBQWdCLFFBQWhCLEVBQTBCLElBQUMsQ0FBQSxPQUFELElBQVksT0FBdEMsRUFBK0MsQ0FBQSxTQUFBLEtBQUE7ZUFBQSxTQUFDLE9BQUQ7VUFDN0MsT0FBTyxDQUFDLEdBQVIsQ0FBWSxxQ0FBQSxHQUFzQyxDQUF0QyxHQUF3QyxnQkFBeEMsR0FBdUQsQ0FBQyxJQUFJLENBQUMsR0FBTCxDQUFBLENBQUEsR0FBYSxTQUFkLENBQXZELEdBQStFLElBQTNGO1VBRUEsU0FBQSxHQUFZLElBQUksQ0FBQyxHQUFMLENBQUE7aUJBQ1osS0FBQyxDQUFBLFFBQUQsQ0FBVSxPQUFWLEVBQW1CLEtBQUMsQ0FBQSxVQUFwQixFQUFnQyxRQUFoQztRQUo2QztNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBL0M7SUFUVyxDQWpFYjtJQWdGQSxlQUFBLEVBQWlCLFNBQUMsUUFBRCxFQUFXLFFBQVg7QUFDZixVQUFBO01BQUEsSUFBQSxHQUFPLElBQUMsQ0FBQSxVQUFXLENBQUEsUUFBQTtNQUNuQixJQUEwQixJQUExQjtBQUFBLGdEQUFPLFNBQVUsZUFBakI7O2FBRUEsSUFBQyxDQUFBLFlBQUQsQ0FBYyxRQUFkLEVBQXdCLElBQXhCLEVBQThCLENBQUEsU0FBQSxLQUFBO2VBQUEsU0FBQTtVQUM1QixJQUFBLEdBQU8sS0FBQyxDQUFBLFVBQVcsQ0FBQSxRQUFBO2tEQUNuQixTQUFVO1FBRmtCO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUE5QjtJQUplLENBaEZqQjs7QUFYRiIsInNvdXJjZXNDb250ZW50IjpbIlxuVGFnR2VuZXJhdG9yID0gcmVxdWlyZSAnLi90YWctZ2VuZXJhdG9yJ1xuY3RhZ3MgPSByZXF1aXJlICdjdGFncydcbmZzID0gcmVxdWlyZSBcImZzXCJcbnBhdGggPSByZXF1aXJlIFwicGF0aFwiXG5cbmdldFRhZ3NGaWxlID0gKGRpcmVjdG9yeVBhdGgpIC0+XG4gIHRhZ3NGaWxlID0gcGF0aC5qb2luKGRpcmVjdG9yeVBhdGgsIFwiLnRhZ3NcIilcbiAgcmV0dXJuIHRhZ3NGaWxlIGlmIGZzLmV4aXN0c1N5bmModGFnc0ZpbGUpXG5cbm1hdGNoT3B0ID0ge21hdGNoQmFzZTogdHJ1ZX1cbm1vZHVsZS5leHBvcnRzID1cbiAgYWN0aXZhdGU6ICgpIC0+XG4gICAgQGNhY2hlZFRhZ3MgPSB7fVxuICAgIEBleHRyYVRhZ3MgPSB7fVxuXG4gIGRlYWN0aXZhdGU6IC0+XG4gICAgQGNhY2hlZFRhZ3MgPSBudWxsXG5cbiAgaW5pdFRhZ3M6IChwYXRocywgYXV0byktPlxuICAgIHJldHVybiBpZiBwYXRocy5sZW5ndGggPT0gMFxuICAgIEBjYWNoZWRUYWdzID0ge31cbiAgICBmb3IgcCBpbiBwYXRoc1xuICAgICAgdGFnc0ZpbGUgPSBnZXRUYWdzRmlsZShwKVxuICAgICAgaWYgdGFnc0ZpbGVcbiAgICAgICAgQHJlYWRUYWdzKHRhZ3NGaWxlLCBAY2FjaGVkVGFncylcbiAgICAgIGVsc2VcbiAgICAgICAgQGdlbmVyYXRlVGFncyhwKSBpZiBhdXRvXG5cbiAgaW5pdEV4dHJhVGFnczogKHBhdGhzKSAtPlxuICAgIEBleHRyYVRhZ3MgPSB7fVxuICAgIGZvciBwIGluIHBhdGhzXG4gICAgICBwID0gcC50cmltKClcbiAgICAgIGNvbnRpbnVlIHVubGVzcyBwXG4gICAgICBAcmVhZFRhZ3MocCwgQGV4dHJhVGFncylcblxuICByZWFkVGFnczogKHAsIGNvbnRhaW5lciwgY2FsbGJhY2spIC0+XG4gICAgY29uc29sZS5sb2cgXCJbYXRvbS1jdGFnczpyZWFkVGFnc10gI3twfSBzdGFydC4uLlwiXG4gICAgc3RhcnRUaW1lID0gRGF0ZS5ub3coKVxuXG4gICAgc3RyZWFtID0gY3RhZ3MuY3JlYXRlUmVhZFN0cmVhbShwKVxuXG4gICAgc3RyZWFtLm9uICdlcnJvcicsIChlcnJvciktPlxuICAgICAgY29uc29sZS5lcnJvciAnYXRvbS1jdGFnczogJywgZXJyb3JcblxuICAgIHN0cmVhbS5vbiAnZGF0YScsICh0YWdzKS0+XG4gICAgICBmb3IgdGFnIGluIHRhZ3NcbiAgICAgICAgY29udGludWUgdW5sZXNzIHRhZy5wYXR0ZXJuXG4gICAgICAgIGRhdGEgPSBjb250YWluZXJbdGFnLmZpbGVdXG4gICAgICAgIGlmIG5vdCBkYXRhXG4gICAgICAgICAgZGF0YSA9IFtdXG4gICAgICAgICAgY29udGFpbmVyW3RhZy5maWxlXSA9IGRhdGFcbiAgICAgICAgZGF0YS5wdXNoIHRhZ1xuICAgIHN0cmVhbS5vbiAnZW5kJywgKCktPlxuICAgICAgY29uc29sZS5sb2cgXCJbYXRvbS1jdGFnczpyZWFkVGFnc10gI3twfSBjb3N0OiAje0RhdGUubm93KCkgLSBzdGFydFRpbWV9bXNcIlxuICAgICAgY2FsbGJhY2s/KClcblxuICAjb3B0aW9ucyA9IHsgcGFydGlhbE1hdGNoOiB0cnVlLCBtYXhJdGVtcyB9XG4gIGZpbmRUYWdzOiAocHJlZml4LCBvcHRpb25zKSAtPlxuICAgIHRhZ3MgPSBbXVxuICAgIHJldHVybiB0YWdzIGlmIEBmaW5kT2YoQGNhY2hlZFRhZ3MsIHRhZ3MsIHByZWZpeCwgb3B0aW9ucylcbiAgICByZXR1cm4gdGFncyBpZiBAZmluZE9mKEBleHRyYVRhZ3MsIHRhZ3MsIHByZWZpeCwgb3B0aW9ucylcblxuICAgICNUT0RPOiBwcm9tcHQgaW4gZWRpdG9yXG4gICAgY29uc29sZS53YXJuKFwiW2F0b20tY3RhZ3M6ZmluZFRhZ3NdIHRhZ3MgZW1wdHksIGRpZCB5b3UgUmVidWlsZFRhZ3Mgb3Igc2V0IGV4dHJhVGFnRmlsZXM/XCIpIGlmIHRhZ3MubGVuZ3RoID09IDBcbiAgICByZXR1cm4gdGFnc1xuXG4gIGZpbmRPZjogKHNvdXJjZSwgdGFncywgcHJlZml4LCBvcHRpb25zKS0+XG4gICAgZm9yIGtleSwgdmFsdWUgb2Ygc291cmNlXG4gICAgICBmb3IgdGFnIGluIHZhbHVlXG4gICAgICAgIGlmIG9wdGlvbnM/LnBhcnRpYWxNYXRjaCBhbmQgdGFnLm5hbWUuaW5kZXhPZihwcmVmaXgpID09IDBcbiAgICAgICAgICAgIHRhZ3MucHVzaCB0YWdcbiAgICAgICAgZWxzZSBpZiB0YWcubmFtZSA9PSBwcmVmaXhcbiAgICAgICAgICB0YWdzLnB1c2ggdGFnXG4gICAgICAgIHJldHVybiB0cnVlIGlmIG9wdGlvbnM/Lm1heEl0ZW1zIGFuZCB0YWdzLmxlbmd0aCA9PSBvcHRpb25zLm1heEl0ZW1zXG4gICAgcmV0dXJuIGZhbHNlXG5cbiAgZ2VuZXJhdGVUYWdzOihwLCBpc0FwcGVuZCwgY2FsbGJhY2spIC0+XG4gICAgZGVsZXRlIEBjYWNoZWRUYWdzW3BdXG5cbiAgICBzdGFydFRpbWUgPSBEYXRlLm5vdygpXG4gICAgY29uc29sZS5sb2cgXCJbYXRvbS1jdGFnczpyZWJ1aWxkXSBzdGFydCBAI3twfUAgdGFncy4uLlwiXG5cbiAgICBjbWRBcmdzID0gYXRvbS5jb25maWcuZ2V0KFwiYXRvbS1jdGFncy5jbWRBcmdzXCIpXG4gICAgY21kQXJncyA9IGNtZEFyZ3Muc3BsaXQoXCIgXCIpIGlmIGNtZEFyZ3NcblxuICAgIFRhZ0dlbmVyYXRvciBwLCBpc0FwcGVuZCwgQGNtZEFyZ3MgfHwgY21kQXJncywgKHRhZ3BhdGgpID0+XG4gICAgICBjb25zb2xlLmxvZyBcIlthdG9tLWN0YWdzOnJlYnVpbGRdIGNvbW1hbmQgZG9uZSBAI3twfUAgdGFncy4gY29zdDogI3tEYXRlLm5vdygpIC0gc3RhcnRUaW1lfW1zXCJcblxuICAgICAgc3RhcnRUaW1lID0gRGF0ZS5ub3coKVxuICAgICAgQHJlYWRUYWdzKHRhZ3BhdGgsIEBjYWNoZWRUYWdzLCBjYWxsYmFjaylcblxuICBnZXRPckNyZWF0ZVRhZ3M6IChmaWxlUGF0aCwgY2FsbGJhY2spIC0+XG4gICAgdGFncyA9IEBjYWNoZWRUYWdzW2ZpbGVQYXRoXVxuICAgIHJldHVybiBjYWxsYmFjaz8odGFncykgaWYgdGFnc1xuXG4gICAgQGdlbmVyYXRlVGFncyBmaWxlUGF0aCwgdHJ1ZSwgPT5cbiAgICAgIHRhZ3MgPSBAY2FjaGVkVGFnc1tmaWxlUGF0aF1cbiAgICAgIGNhbGxiYWNrPyh0YWdzKVxuIl19
