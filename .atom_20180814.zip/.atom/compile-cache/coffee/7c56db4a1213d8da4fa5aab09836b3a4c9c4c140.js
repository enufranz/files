(function() {
  var CtagsProvider, checkSnippet, tagToSuggestion;

  checkSnippet = function(tag) {
    if (tag.kind === "require") {
      return tag.pattern.substring(2, tag.pattern.length - 2);
    }
    if (tag.kind === "function") {
      return tag.pattern.substring(tag.pattern.indexOf(tag.name), tag.pattern.length - 2);
    }
  };

  tagToSuggestion = function(tag) {
    return {
      text: tag.name,
      displayText: tag.pattern.substring(2, tag.pattern.length - 2),
      type: tag.kind,
      snippet: checkSnippet(tag)
    };
  };

  module.exports = CtagsProvider = (function() {
    var prefix_opt, tag_options;

    function CtagsProvider() {}

    CtagsProvider.prototype.selector = '*';

    tag_options = {
      partialMatch: true,
      maxItems: 10
    };

    prefix_opt = {
      wordRegex: /[a-zA-Z0-9_]+[\.\:]/
    };

    CtagsProvider.prototype.getSuggestions = function(arg) {
      var bufferPosition, editor, i, k, len, matches, output, prefix, scopeDescriptor, suggestions, tag;
      editor = arg.editor, bufferPosition = arg.bufferPosition, scopeDescriptor = arg.scopeDescriptor, prefix = arg.prefix;
      if (this.disabled) {
        return [];
      }
      if (prefix === "." || prefix === ":") {
        prefix = editor.getWordUnderCursor(prefix_opt);
      }
      if (!prefix.length) {
        return;
      }
      matches = this.ctagsCache.findTags(prefix, tag_options);
      suggestions = [];
      if (tag_options.partialMatch) {
        output = {};
        k = 0;
        while (k < matches.length) {
          tag = matches[k++];
          if (output[tag.name]) {
            continue;
          }
          output[tag.name] = tag;
          suggestions.push(tagToSuggestion(tag));
        }
        if (suggestions.length === 1 && suggestions[0].text === prefix) {
          return [];
        }
      } else {
        for (i = 0, len = matches.length; i < len; i++) {
          tag = matches[i];
          suggestions.push(tagToSuggestion(tag));
        }
      }
      if (!suggestions.length) {
        return;
      }
      return suggestions;
    };

    return CtagsProvider;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZmlsZTovLy9DOi9Vc2Vycy9mbGlzei8uYXRvbS9wYWNrYWdlcy9hdG9tLWN0YWdzL2xpYi9jdGFncy1wcm92aWRlci5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBOztFQUFBLFlBQUEsR0FBZSxTQUFDLEdBQUQ7SUFFYixJQUFHLEdBQUcsQ0FBQyxJQUFKLEtBQVksU0FBZjtBQUNFLGFBQU8sR0FBRyxDQUFDLE9BQU8sQ0FBQyxTQUFaLENBQXNCLENBQXRCLEVBQXlCLEdBQUcsQ0FBQyxPQUFPLENBQUMsTUFBWixHQUFtQixDQUE1QyxFQURUOztJQUVBLElBQUcsR0FBRyxDQUFDLElBQUosS0FBWSxVQUFmO0FBQ0UsYUFBTyxHQUFHLENBQUMsT0FBTyxDQUFDLFNBQVosQ0FBc0IsR0FBRyxDQUFDLE9BQU8sQ0FBQyxPQUFaLENBQW9CLEdBQUcsQ0FBQyxJQUF4QixDQUF0QixFQUFxRCxHQUFHLENBQUMsT0FBTyxDQUFDLE1BQVosR0FBbUIsQ0FBeEUsRUFEVDs7RUFKYTs7RUFPZixlQUFBLEdBQWtCLFNBQUMsR0FBRDtXQUNoQjtNQUFBLElBQUEsRUFBTSxHQUFHLENBQUMsSUFBVjtNQUNBLFdBQUEsRUFBYSxHQUFHLENBQUMsT0FBTyxDQUFDLFNBQVosQ0FBc0IsQ0FBdEIsRUFBeUIsR0FBRyxDQUFDLE9BQU8sQ0FBQyxNQUFaLEdBQW1CLENBQTVDLENBRGI7TUFFQSxJQUFBLEVBQU0sR0FBRyxDQUFDLElBRlY7TUFHQSxPQUFBLEVBQVMsWUFBQSxDQUFhLEdBQWIsQ0FIVDs7RUFEZ0I7O0VBTWxCLE1BQU0sQ0FBQyxPQUFQLEdBQ007QUFDSixRQUFBOzs7OzRCQUFBLFFBQUEsR0FBVTs7SUFFVixXQUFBLEdBQWM7TUFBRSxZQUFBLEVBQWMsSUFBaEI7TUFBc0IsUUFBQSxFQUFVLEVBQWhDOzs7SUFDZCxVQUFBLEdBQWE7TUFBQyxTQUFBLEVBQVcscUJBQVo7Ozs0QkFFYixjQUFBLEdBQWdCLFNBQUMsR0FBRDtBQUNkLFVBQUE7TUFEZ0IscUJBQVEscUNBQWdCLHVDQUFpQjtNQUN6RCxJQUFhLElBQUMsQ0FBQSxRQUFkO0FBQUEsZUFBTyxHQUFQOztNQUVBLElBQUcsTUFBQSxLQUFVLEdBQVYsSUFBaUIsTUFBQSxLQUFVLEdBQTlCO1FBQ0UsTUFBQSxHQUFTLE1BQU0sQ0FBQyxrQkFBUCxDQUEwQixVQUExQixFQURYOztNQUlBLElBQUEsQ0FBYyxNQUFNLENBQUMsTUFBckI7QUFBQSxlQUFBOztNQUVBLE9BQUEsR0FBVSxJQUFDLENBQUEsVUFBVSxDQUFDLFFBQVosQ0FBcUIsTUFBckIsRUFBNkIsV0FBN0I7TUFFVixXQUFBLEdBQWM7TUFDZCxJQUFHLFdBQVcsQ0FBQyxZQUFmO1FBQ0UsTUFBQSxHQUFTO1FBQ1QsQ0FBQSxHQUFJO0FBQ0osZUFBTSxDQUFBLEdBQUksT0FBTyxDQUFDLE1BQWxCO1VBQ0UsR0FBQSxHQUFNLE9BQVEsQ0FBQSxDQUFBLEVBQUE7VUFDZCxJQUFZLE1BQU8sQ0FBQSxHQUFHLENBQUMsSUFBSixDQUFuQjtBQUFBLHFCQUFBOztVQUNBLE1BQU8sQ0FBQSxHQUFHLENBQUMsSUFBSixDQUFQLEdBQW1CO1VBQ25CLFdBQVcsQ0FBQyxJQUFaLENBQWlCLGVBQUEsQ0FBZ0IsR0FBaEIsQ0FBakI7UUFKRjtRQUtBLElBQUcsV0FBVyxDQUFDLE1BQVosS0FBc0IsQ0FBdEIsSUFBNEIsV0FBWSxDQUFBLENBQUEsQ0FBRSxDQUFDLElBQWYsS0FBdUIsTUFBdEQ7QUFDRSxpQkFBTyxHQURUO1NBUkY7T0FBQSxNQUFBO0FBV0UsYUFBQSx5Q0FBQTs7VUFDRSxXQUFXLENBQUMsSUFBWixDQUFpQixlQUFBLENBQWdCLEdBQWhCLENBQWpCO0FBREYsU0FYRjs7TUFlQSxJQUFBLENBQWMsV0FBVyxDQUFDLE1BQTFCO0FBQUEsZUFBQTs7QUFHQSxhQUFPO0lBOUJPOzs7OztBQXBCbEIiLCJzb3VyY2VzQ29udGVudCI6WyJjaGVja1NuaXBwZXQgPSAodGFnKS0+XG4gICNUT0RPIHN1cHBvcnQgbW9yZSBsYW5ndWFnZVxuICBpZiB0YWcua2luZCA9PSBcInJlcXVpcmVcIlxuICAgIHJldHVybiB0YWcucGF0dGVybi5zdWJzdHJpbmcoMiwgdGFnLnBhdHRlcm4ubGVuZ3RoLTIpXG4gIGlmIHRhZy5raW5kID09IFwiZnVuY3Rpb25cIlxuICAgIHJldHVybiB0YWcucGF0dGVybi5zdWJzdHJpbmcodGFnLnBhdHRlcm4uaW5kZXhPZih0YWcubmFtZSksIHRhZy5wYXR0ZXJuLmxlbmd0aC0yKVxuICAgIFxudGFnVG9TdWdnZXN0aW9uID0gKHRhZyktPlxuICB0ZXh0OiB0YWcubmFtZVxuICBkaXNwbGF5VGV4dDogdGFnLnBhdHRlcm4uc3Vic3RyaW5nKDIsIHRhZy5wYXR0ZXJuLmxlbmd0aC0yKVxuICB0eXBlOiB0YWcua2luZFxuICBzbmlwcGV0OiBjaGVja1NuaXBwZXQodGFnKVxuICAgIFxubW9kdWxlLmV4cG9ydHMgPVxuY2xhc3MgQ3RhZ3NQcm92aWRlclxuICBzZWxlY3RvcjogJyonXG5cbiAgdGFnX29wdGlvbnMgPSB7IHBhcnRpYWxNYXRjaDogdHJ1ZSwgbWF4SXRlbXM6IDEwIH1cbiAgcHJlZml4X29wdCA9IHt3b3JkUmVnZXg6IC9bYS16QS1aMC05X10rW1xcLlxcOl0vfVxuXG4gIGdldFN1Z2dlc3Rpb25zOiAoe2VkaXRvciwgYnVmZmVyUG9zaXRpb24sIHNjb3BlRGVzY3JpcHRvciwgcHJlZml4fSkgLT5cbiAgICByZXR1cm4gW10gaWYgQGRpc2FibGVkXG5cbiAgICBpZiBwcmVmaXggPT0gXCIuXCIgb3IgcHJlZml4ID09IFwiOlwiXG4gICAgICBwcmVmaXggPSBlZGl0b3IuZ2V0V29yZFVuZGVyQ3Vyc29yKHByZWZpeF9vcHQpXG5cbiAgICAjIE5vIHByZWZpeD8gRG9uJ3QgYXV0b2NvbXBsZXRlIVxuICAgIHJldHVybiB1bmxlc3MgcHJlZml4Lmxlbmd0aFxuXG4gICAgbWF0Y2hlcyA9IEBjdGFnc0NhY2hlLmZpbmRUYWdzIHByZWZpeCwgdGFnX29wdGlvbnNcblxuICAgIHN1Z2dlc3Rpb25zID0gW11cbiAgICBpZiB0YWdfb3B0aW9ucy5wYXJ0aWFsTWF0Y2hcbiAgICAgIG91dHB1dCA9IHt9XG4gICAgICBrID0gMFxuICAgICAgd2hpbGUgayA8IG1hdGNoZXMubGVuZ3RoXG4gICAgICAgIHRhZyA9IG1hdGNoZXNbaysrXVxuICAgICAgICBjb250aW51ZSBpZiBvdXRwdXRbdGFnLm5hbWVdXG4gICAgICAgIG91dHB1dFt0YWcubmFtZV0gPSB0YWdcbiAgICAgICAgc3VnZ2VzdGlvbnMucHVzaCB0YWdUb1N1Z2dlc3Rpb24odGFnKVxuICAgICAgaWYgc3VnZ2VzdGlvbnMubGVuZ3RoID09IDEgYW5kIHN1Z2dlc3Rpb25zWzBdLnRleHQgPT0gcHJlZml4XG4gICAgICAgIHJldHVybiBbXVxuICAgIGVsc2VcbiAgICAgIGZvciB0YWcgaW4gbWF0Y2hlc1xuICAgICAgICBzdWdnZXN0aW9ucy5wdXNoIHRhZ1RvU3VnZ2VzdGlvbih0YWcpXG5cbiAgICAjIE5vIHN1Z2dlc3Rpb25zPyBEb24ndCBhdXRvY29tcGxldGUhXG4gICAgcmV0dXJuIHVubGVzcyBzdWdnZXN0aW9ucy5sZW5ndGhcblxuICAgICMgTm93IHdlJ3JlIHJlYWR5IC0gZGlzcGxheSB0aGUgc3VnZ2VzdGlvbnNcbiAgICByZXR1cm4gc3VnZ2VzdGlvbnNcbiJdfQ==
