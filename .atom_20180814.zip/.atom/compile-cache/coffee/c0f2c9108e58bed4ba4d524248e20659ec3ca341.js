(function() {
  var CommandError;

  CommandError = (function() {
    function CommandError(message) {
      this.message = message;
      this.name = 'Command Error';
    }

    return CommandError;

  })();

  module.exports = CommandError;

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZmlsZTovLy9DOi9Vc2Vycy9mbGlzei8uYXRvbS9wYWNrYWdlcy9leC1tb2RlL2xpYi9jb21tYW5kLWVycm9yLmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUE7O0VBQU07SUFDUyxzQkFBQyxPQUFEO01BQUMsSUFBQyxDQUFBLFVBQUQ7TUFDWixJQUFDLENBQUEsSUFBRCxHQUFRO0lBREc7Ozs7OztFQUdmLE1BQU0sQ0FBQyxPQUFQLEdBQWlCO0FBSmpCIiwic291cmNlc0NvbnRlbnQiOlsiY2xhc3MgQ29tbWFuZEVycm9yXG4gIGNvbnN0cnVjdG9yOiAoQG1lc3NhZ2UpIC0+XG4gICAgQG5hbWUgPSAnQ29tbWFuZCBFcnJvcidcblxubW9kdWxlLmV4cG9ydHMgPSBDb21tYW5kRXJyb3JcbiJdfQ==
