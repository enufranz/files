(function() {
  var GlobalExState;

  GlobalExState = (function() {
    function GlobalExState() {}

    GlobalExState.prototype.commandHistory = [];

    GlobalExState.prototype.setVim = function(vim) {
      this.vim = vim;
    };

    return GlobalExState;

  })();

  module.exports = GlobalExState;

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZmlsZTovLy9DOi9Vc2Vycy9mbGlzei8uYXRvbS9wYWNrYWdlcy9leC1tb2RlL2xpYi9nbG9iYWwtZXgtc3RhdGUuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQUEsTUFBQTs7RUFBTTs7OzRCQUNKLGNBQUEsR0FBZ0I7OzRCQUNoQixNQUFBLEdBQVEsU0FBQyxHQUFEO01BQUMsSUFBQyxDQUFBLE1BQUQ7SUFBRDs7Ozs7O0VBRVYsTUFBTSxDQUFDLE9BQVAsR0FBaUI7QUFKakIiLCJzb3VyY2VzQ29udGVudCI6WyJjbGFzcyBHbG9iYWxFeFN0YXRlXG4gIGNvbW1hbmRIaXN0b3J5OiBbXVxuICBzZXRWaW06IChAdmltKSAtPlxuXG5tb2R1bGUuZXhwb3J0cyA9IEdsb2JhbEV4U3RhdGVcbiJdfQ==
